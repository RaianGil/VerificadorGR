﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VerificadorGR.Model
{
    public class Puntos
    {
        public string Nombre { get; set; }
        public string PuntosAcumulados { get; set; }
    }
}
