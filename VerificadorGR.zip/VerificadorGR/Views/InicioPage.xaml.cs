﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml.Linq;
using VerificadorGR.Model;
using Xamarin.Essentials;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace VerificadorGR.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class InicioPage : ContentPage
    {
        public InicioPage()
        {
            InitializeComponent();
            Device.StartTimer(TimeSpan.FromSeconds(2), () =>
            {

                //Device.BeginInvokeOnMainThread(() => entCodigo.Focus());

                return true;

            });
            entCodigo.Focus();
        }
        protected override void OnAppearing() //Cuando aparezca la pagina, refrescamos.
        {
            entCodigo.Focus();
        }
        
       

        private async void Entry_Completed(object sender, EventArgs e)
        {
            try
            {
                SqlConnection sql = new SqlConnection(@"Data Source=DESKTOP-9RCFTGH;Initial Catalog=VerificadorPrueba");

                sql.Open();

                SqlCommand command = new SqlCommand("select Descripcion, PrecioConItbis from xVs_PreciosITBIS where key in (" + sender.ToString() + ")" , sql);

                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    Producto producto = new Producto();
                    producto.Descripcion = reader.GetValue(0).ToString();
                    producto.Precio = reader.GetValue(1).ToString();

                    await Navigation.PushModalAsync(new PrecioDatosPage(producto));
                    Console.WriteLine(reader.GetValue(0));
                }

                sql.Close();
            }
            catch
            {
                Console.WriteLine("Error");
            }
        }

        private async void imgSirena_Clicked(object sender, EventArgs e)
        {
            try
            {
                
                await Navigation.PushModalAsync(new ConfigPage());
            }
            catch (Exception ea)
            {
                var x = ea.Message;
                //throw;
            }
           
        }

        private async void Entry_Completed_1(object sender, EventArgs e)
        {
            try
            {
                await Navigation.PushModalAsync(new ConfigPage());
            }
            catch (Exception ea)
            {
                var x = ea.Message;
                //throw;
            }
        }
    }
}